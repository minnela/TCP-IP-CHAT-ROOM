import java.io.*;
import java.net.Socket;

public class ClientThread extends Thread {
    public Socket istemciSoketi;



    public ClientThread(Socket istemciSoketi) {

        this.istemciSoketi = istemciSoketi;


    }

    @Override
    public void run(){
        BufferedReader reader = null;
        try {
            reader = OpenBuffReader(istemciSoketi);
        } catch (IOException e) {
            e.printStackTrace();
        }

        BufferedWriter BW = null;
        try {
            BW = OpenBuffWriter(istemciSoketi);
        } catch (IOException e) {
            e.printStackTrace();
        }
        /* soketin yazıcısı */
        PrintWriter out = new PrintWriter(BW, true);

        String str = null;
        while (true) {
            try {
                str = reader.readLine();
                if(str != null)
                    break;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if(str.startsWith("Register:")) {
            try {
                RegisterRequest(str,reader,out);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if(str.startsWith("Login:"))
        {
            try {
                login(str,reader,out);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if(str.startsWith("Message:")){

            try {
                message(str,reader,out);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if(str.startsWith("MesajCek:"))
        {
            try {
                GecmisMesajlarıGetir(str,reader,out);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if(str.startsWith("Search:")){

            try {
                aramaYap(str,reader,out);
            } catch (IOException e) {
                e.printStackTrace();
            }


        }

    }

    public BufferedReader OpenBuffReader(Socket clientSocket) throws IOException {
        InputStream IS = clientSocket.getInputStream();
        InputStreamReader ISR = new InputStreamReader(IS);
        return new BufferedReader(ISR);
    }
    /* bufferedwriter opener */
    public BufferedWriter OpenBuffWriter(Socket clientSocket) throws IOException {
        OutputStream OS = clientSocket.getOutputStream();
        OutputStreamWriter OSR = new OutputStreamWriter(OS);
        return new BufferedWriter(OSR);
    }

    public void RegisterRequest(String str,BufferedReader reader,PrintWriter out) throws IOException {


            System.out.println("Register request from:" + str);

            // DOSYAYA YAZMA YAPICAK ELEMAN
            PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter("users.txt", true)));

            // DOSYADAKi satırları tek tek okuyup, kayıt etmek istediğimiz kullanıcı daha önce alınmışsa hata geri dönüş bilgisi yolluyoruz.
            BufferedReader fileReader = new BufferedReader(new FileReader("users.txt"));
            String line = fileReader.readLine();
            while (line != null) {
                if (line.equals(str.substring(9))) {
                    out.println("ThisUsernameHasAlreadyTaken:");
                    return;
                }
                line = fileReader.readLine();
            }


            writer.println(str.substring(9));
            writer.close();
            out.println("UserRegistered:");


        }
        public void login(String str,BufferedReader reader,PrintWriter out) throws IOException {

            PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter("users.txt", true)));

            System.out.println("Login request from: " + str );
            BufferedReader reader1= new BufferedReader(new FileReader("users.txt"));
            String line = reader1.readLine();
            while (line != null) {
                if (line.equals(str.substring(6))) {
                    out.println("SuccessfullyLogin");
                    return;
                }
                line = reader1.readLine();
            }
            writer.close();
            out.println("TheUserNotFound");


             // gelen stringden substring() kullanarak kullanıcı adı kısmını ayıkla
            // Login:Minella gibi bir şey geldiyse mesela substring(6) kullanarak stringi sadece Minellaya çevir
            // gelen kullanıcı adı, kullanıcı adlarını içeren txt dosyasında var ise
            // bu kullanıcı giriş yapabilir.
            // server successfullLogin tarzı bir mesaj yollasın geri cliente.
            // Client böyle bir mesaj aldığında, yeni bir JFRame açsın ve ona geçiş yapsın.
            // Bu JFramenin ismide mesajlaşma ekranı olcak.

            // eğer kullanıcı adı, dosyadaki hiçbir satırda yok ise, cliente thisUserNotFound tarzı bir hata yolla
            // client bu hatayı alınca ekrana bastırsın ki, şunu bastırsın. Böyle bir kullanıcı yok


        }
    public void message(String str,BufferedReader reader,PrintWriter out) throws IOException {

        PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter("mesajlar.txt", true)));
        writer.println(str.substring(8));
        writer.close();
    }

     public void GecmisMesajlarıGetir(String str,BufferedReader reader,PrintWriter out) throws IOException
     {
         System.out.println("Gecmis Mesajları Getirmek istendi");

         BufferedReader dosyaOkuyucu = new BufferedReader(new FileReader("mesajlar.txt"));

         String line = dosyaOkuyucu.readLine();

         String messageToAnswer = line;

         while(line != null)
         {
             if(!line.equals("")) {
                 line = dosyaOkuyucu.readLine();
                 messageToAnswer += "---" + line;
             }
         }

         out.println(messageToAnswer);

     }

     public void aramaYap(String str,BufferedReader reader,PrintWriter out) throws IOException{

         System.out.println("Arama yapılmak istendi");
         System.out.println(str.substring(7));
         PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter("searchHistory.txt", true)));
         writer.println(str.substring(7));
         writer.close();


         BufferedReader dosyaOkuyucu = new BufferedReader(new FileReader("mesajlar.txt"));

         String line = dosyaOkuyucu.readLine();

         String searchingMessage = line;
         while(line != null)
         {
             if(line.contains(str.substring(7))) {
                 searchingMessage += "-----" + line;
             }
             line = dosyaOkuyucu.readLine();
         }
         System.out.println(searchingMessage);
         out.println(searchingMessage);

     }

}






































