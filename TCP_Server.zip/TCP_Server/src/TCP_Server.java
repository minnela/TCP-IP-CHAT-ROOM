import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class TCP_Server {

    private static ServerSocket sunucuSoketi= null; //sunucu soketi açma
    private static Socket istemciSoketi=null; //istemci soketi açma

    public static void main(String args[]) throws IOException {
        int portNo = 8888;


        Listening(portNo);

    }


    public static void Listening(int portNo) throws IOException{
            try {
                sunucuSoketi = new ServerSocket(portNo);
            } catch (IOException e) {
                System.out.println(e);
            }

           while (true){

               System.out.println("Listening....");
               try{
                   istemciSoketi=sunucuSoketi.accept();
                       new ClientThread(istemciSoketi).start();
               } catch (IOException e) {
                   System.out.println(e);
               }
           }


        }

























}
