import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

    public static boolean  aramaActivated = false;

    public static void main(String[] args) {


        JFrame frame = new JFrame("Minnella's Client");
        JPanel panel = new JPanel();
        panel.setLayout(null);
        JLabel usernameLabel = new JLabel("Username");
        JLabel kayitLabel = new JLabel("Kayıt ol");

        JTextArea kullaniciGirisi = new JTextArea();
        JTextArea kayitGirisi = new JTextArea();

        JButton buttonLogin = new JButton("LogIn");
        JButton kayitButton = new JButton("Kayıt");

        ImageIcon icon = new ImageIcon("C:\\Users\\minel\\OneDrive\\Masaüstü");
        JLabel anaJLabel = new JLabel(icon);

        anaJLabel.setBounds(50,200,200,200);


        usernameLabel.setBounds(5, 50, 100, 25);
        kayitLabel.setBounds(5, 130, 100, 25);
        kullaniciGirisi.setBounds(100, 50, 100, 25);
        kayitGirisi.setBounds(100, 130, 100, 25);
        kayitButton.setBounds(200, 130, 100, 25);

        buttonLogin.setBounds(200, 57, 100, 25);

        panel.add(anaJLabel);
        panel.add(kayitButton);
        panel.add(usernameLabel);
        panel.add(kayitLabel);
        panel.add(buttonLogin);
        panel.add(kullaniciGirisi);
        panel.add(kayitGirisi);
        frame.add(panel);
        frame.setSize(800, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        buttonLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Socket mesajYollayici = null;
                try {

                    mesajYollayici = new Socket("127.0.0.1", 8888);

                } catch (UnknownHostException e1) {
                    e1.printStackTrace();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }

                BufferedReader reader = null;
                try {
                    reader = OpenBuffReader(mesajYollayici);
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                BufferedWriter BW = null;
                try {
                    BW = OpenBuffWriter(mesajYollayici);
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
                PrintWriter out = new PrintWriter(BW, true);


                out.println("Login:" + kullaniciGirisi.getText());


                try {
                    while (true) {
                        String answer = null;
                        try {
                            answer = reader.readLine();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                        if (answer != null && answer.startsWith("TheUserNotFound")) {
                            JOptionPane.showMessageDialog(null, "The user is not found", "Error", JOptionPane.WARNING_MESSAGE);
                            return;
                        } else if (answer != null && answer.startsWith("SuccessfullyLogin")) {
                            JOptionPane.showMessageDialog(null, "User successfully Logged In", "Info", JOptionPane.PLAIN_MESSAGE);
                            chatFrame(kullaniciGirisi.getText());

                            return;
                        }
                    }
                } catch (Exception e2) {
                    JOptionPane.showMessageDialog(null, e2.getMessage(), "An Error Occured during connection. Connection closing...", JOptionPane.PLAIN_MESSAGE);
                    return;
                }


            }
        });

        kayitButton.addActionListener((new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Socket mesajYollayici = null;
                try {
                    mesajYollayici = new Socket("localhost", 8888);
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                BufferedReader reader = null;
                try {
                    reader = OpenBuffReader(mesajYollayici);
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                BufferedWriter BW = null;
                try {
                    BW = OpenBuffWriter(mesajYollayici);
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
                PrintWriter out = new PrintWriter(BW, true);

                System.out.println(kayitGirisi.getText());

                out.println("Register:" + kayitGirisi.getText());

                // CLIENT SERVERDEN GEri DÖNÜŞ bekliyor
                // ThisUsernameHasAlreadyTaken:

                try {
                    while (true) {
                        String answer = null;
                        try {
                            answer = reader.readLine();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                        if (answer != null && answer.startsWith("ThisUsernameHasAlreadyTaken:")) {
                            JOptionPane.showMessageDialog(null, "This username is already taken", "Error", JOptionPane.WARNING_MESSAGE);
                            return;
                        } else if (answer != null && answer.startsWith("UserRegistered:")) {
                            JOptionPane.showMessageDialog(null, "User registered successfully", "Error", JOptionPane.PLAIN_MESSAGE);
                            return;
                        }
                    }
                } catch (Exception e2) {
                    JOptionPane.showMessageDialog(null, e2.getMessage(), "An Error Occured during connection. Connection closing...", JOptionPane.PLAIN_MESSAGE);
                    return;
                }


            }
        }));
    }

    public static void chatFrame(String username) {


        JFrame frame = new JFrame("MinnelApps");
        frame.setLayout(null);
        JTextArea mesajKismi = new JTextArea();
        JTextArea yollanacakMesaj = new JTextArea();
        JLabel currentUser = new JLabel();
        JButton sendButton = new JButton("SEND");
        JButton searchButton = new JButton(("Search:"));
        JTextArea aramaBolgesi = new JTextArea();



        mesajKismi.setBounds(10, 10, 300, 300);
        yollanacakMesaj.setBounds(10, 330, 300, 30);
        sendButton.setBounds(320, 310, 100, 25);
        currentUser.setBounds(400, 5, 350, 25);
        searchButton.setBounds(320, 200, 100, 25);
        aramaBolgesi.setBounds(420, 200, 250, 25);


        currentUser.setText("Giris yapan Kullanıcı: " + username);
        frame.add(currentUser);
        frame.add(yollanacakMesaj);
        frame.add(mesajKismi);
        frame.add(sendButton);
        frame.add(searchButton);
        frame.add(aramaBolgesi);



        frame.setSize(800, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);



           sendButton.addActionListener(new ActionListener() {
                @Override
            public void actionPerformed(ActionEvent e) {
                    Socket mesajYollayici=null;
                    try {
                         mesajYollayici= new Socket("127.0.0.1", 8888);
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                    BufferedReader reader = null;
                    try {
                        reader = OpenBuffReader(mesajYollayici);
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                    BufferedWriter BW = null;
                    try {
                        BW = OpenBuffWriter(mesajYollayici);
                    } catch (IOException e3) {
                        e3.printStackTrace();
                    }
                    PrintWriter out = new PrintWriter(BW, true);
                    out.println("Message:"+username+":" + yollanacakMesaj.getText());
                }
 });

        Thread mesajCekici = new Thread(new Runnable() {
            @Override
            public void run() {

               while(true)
               {
                   if(aramaBolgesi.getText().equals("")) {
                       Socket mesajYollayici = null;
                       try {
                           mesajYollayici = new Socket("127.0.0.1", 8888);
                       } catch (IOException e1) {
                           e1.printStackTrace();
                       }
                       BufferedReader reader = null;
                       try {
                           reader = OpenBuffReader(mesajYollayici);
                       } catch (IOException e2) {
                           e2.printStackTrace();
                       }
                       BufferedWriter BW = null;
                       try {
                           BW = OpenBuffWriter(mesajYollayici);
                       } catch (IOException e3) {
                           e3.printStackTrace();
                       }
                       PrintWriter out = new PrintWriter(BW, true);
                       out.println("MesajCek:");

                       try {
                           while (true) {
                               String answer = null;
                               try {
                                   answer = reader.readLine();
                               } catch (IOException e1) {
                                   e1.printStackTrace();
                               }
                               if (answer != null) {
                                   // Mesaj1---Mesaj2---Mesaj3
                                   // Dizi[0] = Mesaj1;
                                   // Dizi[1] = Mesaj2;
                                   // Dizi[2] = Mesaj3;
                                   String[] mesajlarDizisi = answer.split("---");
                                   mesajKismi.setText("");

                                   for (int i = 0; i < mesajlarDizisi.length - 1; i++) {
                                       mesajKismi.append(mesajlarDizisi[i] + "\n");
                                   }
                                   break;
                               }
                           }
                       } catch (Exception e2) {
                           JOptionPane.showMessageDialog(null, e2.getMessage(), "An Error Occured during connection. Connection closing...", JOptionPane.PLAIN_MESSAGE);
                           return;
                       }
                       try {
                           Thread.sleep(1000);
                       } catch (InterruptedException e) {
                           e.printStackTrace();
                       }
                   }
               }
            }
        });
           mesajCekici.start();
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Socket mesajYollayici = null;
                try {
                    mesajYollayici = new Socket("127.0.0.1", 8888);
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                BufferedReader reader = null;
                try {
                    reader = OpenBuffReader(mesajYollayici);
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                BufferedWriter BW = null;
                try {
                    BW = OpenBuffWriter(mesajYollayici);
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
                PrintWriter out = new PrintWriter(BW, true);
                out.println("Search:" + aramaBolgesi.getText());
                try {
                    while (true) {
                        String answer = null;
                        try {
                            answer = reader.readLine();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                        if (answer != null ) {
                            aramaActivated =  true;
                            mesajKismi.setText("");
                            String[] mesajlarDizisi = answer.split("-----");

                            for(int i =1;i<mesajlarDizisi.length;i++)
                            {
                                mesajKismi.append(mesajlarDizisi[i]+"\n");
                            }
                           /* Highlighter highlighter = mesajKismi.getHighlighter();
                            Highlighter.HighlightPainter painter = new DefaultHighlighter.DefaultHighlightPainter(Color.RED);
                            highlighter.addHighlight(0 , 10, painter);
                            JOptionPane.showMessageDialog(null, "Message is Found", "Error", JOptionPane.WARNING_MESSAGE);*/
                            return;
                        }
                    }
                } catch (Exception e2) {
                    JOptionPane.showMessageDialog(null, e2.getMessage(), "An Error Occured during connection. Connection closing...", JOptionPane.PLAIN_MESSAGE);
                    return;
                }


            }
        });

        aramaBolgesi.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                if (aramaBolgesi.getText().equals("")) {
                    aramaActivated = false;
                    return;
                }
                Socket mesajYollayici = null;
                try {
                    mesajYollayici = new Socket("127.0.0.1", 8888);
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                BufferedReader reader = null;
                try {
                    reader = OpenBuffReader(mesajYollayici);
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                BufferedWriter BW = null;
                try {
                    BW = OpenBuffWriter(mesajYollayici);
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
                PrintWriter out = new PrintWriter(BW, true);
                out.println("Search:" + aramaBolgesi.getText());
                try {
                    while (true) {
                        String answer = null;
                        try {
                            answer = reader.readLine();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                        if (answer != null) {
                            aramaActivated = true;
                            mesajKismi.setText("");
                            String[] mesajlarDizisi = answer.split("-----");

                            for (int i = 1; i < mesajlarDizisi.length; i++) {
                                mesajKismi.append(mesajlarDizisi[i] + "\n");
                            }
                           /* Highlighter highlighter = mesajKismi.getHighlighter();
                            Highlighter.HighlightPainter painter = new DefaultHighlighter.DefaultHighlightPainter(Color.RED);
                            highlighter.addHighlight(0 , 10, painter);
                            JOptionPane.showMessageDialog(null, "Message is Found", "Error", JOptionPane.WARNING_MESSAGE);*/
                            return;
                        }
                    }
                } catch (Exception e2) {
                    JOptionPane.showMessageDialog(null, e2.getMessage(), "An Error Occured during connection. Connection closing...", JOptionPane.PLAIN_MESSAGE);
                    return;
                }

            }


            @Override
            public void removeUpdate(DocumentEvent e) {
                if (aramaBolgesi.getText().equals("")) {
                    aramaActivated = false;
                    return;
                }
                Socket mesajYollayici = null;
                try {
                    mesajYollayici = new Socket("127.0.0.1", 8888);
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                BufferedReader reader = null;
                try {
                    reader = OpenBuffReader(mesajYollayici);
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                BufferedWriter BW = null;
                try {
                    BW = OpenBuffWriter(mesajYollayici);
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
                PrintWriter out = new PrintWriter(BW, true);
                out.println("Search:" + aramaBolgesi.getText());
                try {
                    while (true) {
                        String answer = null;
                        try {
                            answer = reader.readLine();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                        if (answer != null) {
                            aramaActivated = true;
                            mesajKismi.setText("");
                            String[] mesajlarDizisi = answer.split("-----");

                            for (int i = 1; i < mesajlarDizisi.length; i++) {
                                mesajKismi.append(mesajlarDizisi[i] + "\n");
                            }
                           /* Highlighter highlighter = mesajKismi.getHighlighter();
                            Highlighter.HighlightPainter painter = new DefaultHighlighter.DefaultHighlightPainter(Color.RED);
                            highlighter.addHighlight(0 , 10, painter);
                            JOptionPane.showMessageDialog(null, "Message is Found", "Error", JOptionPane.WARNING_MESSAGE);*/
                            return;
                        }
                    }
                } catch (Exception e2) {
                    JOptionPane.showMessageDialog(null, e2.getMessage(), "An Error Occured during connection. Connection closing...", JOptionPane.PLAIN_MESSAGE);
                    return;
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                if (aramaBolgesi.getText().equals("")) {
                    aramaActivated = false;
                    return;
                }
            }

        });


    }



    public static BufferedReader OpenBuffReader(Socket clientSocket) throws IOException {
        InputStream IS = clientSocket.getInputStream();
        InputStreamReader ISR = new InputStreamReader(IS);
        return new BufferedReader(ISR);
    }
    /* bufferedwriter opener */
    public static BufferedWriter OpenBuffWriter(Socket clientSocket) throws IOException {
        OutputStream OS = clientSocket.getOutputStream();
        OutputStreamWriter OSR = new OutputStreamWriter(OS);
        return new BufferedWriter(OSR);
    }


}
